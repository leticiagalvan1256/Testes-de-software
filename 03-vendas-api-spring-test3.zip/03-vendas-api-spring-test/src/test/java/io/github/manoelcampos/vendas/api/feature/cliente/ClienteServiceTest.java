package io.github.manoelcampos.vendas.api.feature.cliente;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ClienteServiceTest {
    @InjectMocks
    private ClienteService service;

    @Mock
    private ClienteRepository repository;

    @Test
    void findByCPF() {
        final var cpfComSimbolos = "331.847.550-53";
        final var cpfSemSimbolos = "33184755053";

        var caixa = Optional.of(new Cliente("Manoel", cpfSemSimbolos,null));
        Mockito.when(repository.findByCpf(cpfSemSimbolos)).
                thenReturn(caixa);
        //assertTrue(service.findByCpf(cpfComSimbolos).isPresent());
        //assertTrue(service.findByCpf(cpfSemSimbolos).isPresent());

        var cliente1 = service.findByCpf(cpfComSimbolos).orElseThrow();
        var cliente2 = service.findByCpf(cpfSemSimbolos).orElseThrow();

        assertEquals(cpfComSimbolos,cliente1.getCpf());
        assertEquals(cpfComSimbolos,cliente2.getCpf());


    }
}