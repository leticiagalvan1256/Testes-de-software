package io.github.manoelcampos.vendas.api.feature.cidade;

import org.assertj.core.util.Preconditions;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springdoc.core.service.GenericResponseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.*;

// Java Bean (bean = feijão ou grão): objeto java com getters e setters
// Spring bean: objeto gerenciado pelo Spring.
// JPA = Java Persistence API: é apenas uma especificação (como uma norma)
// (API de Object Relational Mapping - ORM: Mapeamento Objeto-Relacional)
@DataJpaTest
class CidadeRepositoryTest {
    /// Injeção de Dependêndica: instanciar automaticamente objetos
    /// Só funciona se a classe onde o objeto será instanciado
    /// for um Spring Bean, ou seja, for um objeto criado e gerenciado
    /// pelo Spring.
    /// `@Autowirded`: pedir pro spring instanciar um objeto pra mim.
    /// Ele só faz isso com objetos Spring Bean.
    @Autowired
    private CidadeRepository repository;

    @Test
    void findByDescricaoLike() {
        final var listaObtida = repository.findByDescricaoLike("São %");

        final var listaEsperada =
                List.of(
                        new Cidade(1L, "São Paulo"),
                        new Cidade(13L, "São Luiz"),
                        new Cidade(28L, "São José dos Campos"));
        assertThat(listaObtida).size().isEqualTo(listaEsperada.size());
        assertThat(listaObtida).containsAll(listaEsperada);
    }


    @Test
    void deleteById() {
        //Uma variável é como uma caixa também,
        // mas quando ela contém null, é como se a caixa nao existisse
        //Cidade cidade =  null;
        //cidade.getId()

        final long id = 28;
        // TODO Usar Preconditions do AssertJ (ou do JUnit)
        assertThat(repository.findById(id)).isPresent();

        // delete from cidade where id = 28
        repository.deleteById(id);

        // Optional é como uma caixa que conter algo ou não
        assertThat(repository.findById(id)).isEmpty();
    }

    @Test
    void deleteByIdLancaExcessaoFK() {
        final long id = 4;
        //repository.deleteById(id);
        //repository.flush();

        assertThatThrownBy(() -> {
            repository.deleteById(id);
            repository.flush();
        }).isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void updateCidade() {
        final long id = 28;
        final var nomeCidadeEsperado = "SÃO JOSÉ DOS CAMPOS";

        var cidade = getCidade(id);
        cidade.setDescricao(nomeCidadeEsperado);
        repository.saveAndFlush(cidade);

       // var cidadeObtida = getCidade(id);
        //assertThat(cidadeObtida.getDescricao()).isEqualsTo(nomeCidadeEsperado);

    }

    private @NotNull Cidade getCidade(long id) {
        Cidade cidade = repository.findById(id).orElseThrow();
        return cidade;
    }
}
